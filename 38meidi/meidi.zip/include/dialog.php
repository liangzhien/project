
<div class="pop pop_pro">
	<div class="bd">
		<a href="javascript:;" class="btn_close"><img src="images/ico_close.png" alt=""></a>
		<div class="inner">
			<img src="images/blank.png" data-src="images/pic_pro.jpg" class="load" alt="">
		</div>
	</div>
</div>
<div class="pop pop_share">
	<div class="bd">
		<img src="images/blank.png" data-src="images/pic_share.png" class="load" alt="">
	</div>
</div>
<!--砍价-->
<div class="pop pop_make">
	<div class="bd">
		<a href="javascript:;" class="btn_close"><img src="images/ico_close.png" alt=""></a>
		<div class="inner">
			<img src="images/blank.png" data-src="images/pic_make.jpg" class="load" alt="">
			<div class="txt">
				<span>XXX</span>元
			</div>
		</div>
	</div>
</div>
<!--0元购净水机-->
<div class="pop pop_zero">
	<div class="bd">
		<a href="javascript:;" class="btn_close"><img src="images/ico_close.png" alt=""></a>
		<div class="inner price_con">
			<div class="p p1">
				<img src="images/tem.jpg" alt="">
			</div>
			<div class="name">恩恩</div>
			<div class="p p2">
				<img src="images/blank.png" data-src="images/pic2.jpg"  class="load" alt="">
			</div>	
			<div class="code">
				<img src="images/code.png" alt="">
			</div>	
			<div class="p p3">
				<img src="images/blank.png" data-src="images/pic4.jpg"  class="load" alt="">
			</div>								
		</div>
	</div>
</div>
<!--半价购净水机-->
<div class="pop pop_half" >
	<div class="bd">
		<a href="javascript:;" class="btn_close"><img src="images/ico_close.png" alt=""></a>
		<div class="inner price_con">
			<div class="p p1">
				<img src="images/tem.jpg" alt="">
			</div>
			<div class="name">恩恩</div>
			<div class="p p2">
				<img src="images/blank.png" data-src="images/pic3.jpg"  class="load" alt="">
			</div>	
			<div class="code">
				<img src="images/code.png" alt="">
			</div>	
			<div class="p p3">
				<img src="images/blank.png" data-src="images/pic6.jpg"  class="load" alt="">
			</div>									
		</div>
	</div>
</div>